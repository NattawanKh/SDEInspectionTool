# label-generator

This program is use for flashing a mcu

## Features

- flashing hex file tutorial
- read mac address and add to
- Feature 3

## Getting Started

### Prerequisites

- Python 3.x
- Additional libraries or packages (if any)

### Installation

```bash
pip install your-package-name
```
